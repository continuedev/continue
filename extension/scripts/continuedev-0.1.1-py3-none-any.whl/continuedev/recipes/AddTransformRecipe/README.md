# AddTransformRecipe

Uses the Chess.com API example to show how to add map and filter Python transforms to a dlt pipeline.