# AddTransformRecipe

Uses the Chess.com API example to show how to add map and filter Python transforms to a dlt pipeline.

Background
- https://dlthub.com/docs/general-usage/resource#filter-transform-and-pivot-data
- https://dlthub.com/docs/customizations/customizing-pipelines/renaming_columns
- https://dlthub.com/docs/customizations/customizing-pipelines/pseudonymizing_columns