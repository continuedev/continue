# DDtoBQRecipe

Move from using DuckDB to Google BigQuery as the destination for your `dlt` pipeline