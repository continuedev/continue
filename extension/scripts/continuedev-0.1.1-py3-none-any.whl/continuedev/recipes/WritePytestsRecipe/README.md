# CreatePytestsRecipe

A recipe for writing unit tests in Pytest.

# How to use this recipe

Call this recipe with a python file open that you would like to test. It will create tests in a `tests/` folder adjacent to the file with the test file given the same name prepended by `test_`.
