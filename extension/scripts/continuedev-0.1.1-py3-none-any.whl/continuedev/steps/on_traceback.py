from ..core.main import Step
from ..core.sdk import ContinueSDK
from .chat import SimpleChatStep


class DefaultOnTracebackStep(Step):
    output: str
    name: str = "Help With Traceback"
    hide: bool = True

    async def run(self, sdk: ContinueSDK):
        sdk.run_step(SimpleChatStep(user_input=self.output))
